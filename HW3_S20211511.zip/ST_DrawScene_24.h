﻿//
//  ST_DrawScene_24.h
//
//  Written for CSE4170
//  Department of Computer Science and Engineering
//  Copyright © 2024 Sogang University. All rights reserved.
//

#pragma once

void ST_drawScene_24(int argc, char* argv[]);